#!/usr/bin/env python
"""EPNN model classes and functionalities"""
from dataclasses import dataclass
from datetime import datetime
from typing import Any, Callable

import flax.linen
import jax
import jax.numpy as jnp
import jraph


class MLP(flax.linen.Module):
    """
    Multilayer perceptron used to generate the messages for passing

    :param features: Sequence of layer widths. The last layer has to have a width corresponding to the
        feature dimension of the EPNN node features
    :param activation_function: Activation function to be used. Default is jax.nn.selu
    """

    features: tuple[int, ...]
    activation_function: Callable[[jnp.ndarray], jnp.ndarray] = jax.nn.selu

    @flax.linen.compact
    def __call__(self, inputs: jnp.ndarray):
        result = self.activation_function(
            flax.linen.Dense(self.features[0], name="stage_0")(inputs)
        )
        for f_index, features in enumerate(self.features[1:]):
            result = self.activation_function(
                flax.linen.Dense(features, name=f"stage_{f_index + 1}")(result)
            )
        return result


def _aggregate_nodes_fn(
    electron_pass_messages: jnp.ndarray,
    receivers: jnp.ndarray,
    cutoff_mask: jnp.ndarray,
    n_nodes: int,
) -> jnp.ndarray:
    """
    Function that aggregates electron passes for receiver nodes

    :param electron_pass_messages: Array of electron pass messages to be aggregated
    :param receivers: Array of receivers defined in jraph.GraphTuple
    :param cutoff_mask: Cutoff mask for node and edge interactions
    :param n_nodes: Total number of nodes
    :return: Aggregated received attributes
    """
    # Weight the edges with the cutoff mask
    electron_pass_messages = jnp.multiply(electron_pass_messages, cutoff_mask)
    # Sum values for each receiver node
    return jax.ops.segment_sum(electron_pass_messages, receivers, n_nodes)


class EPNN(flax.linen.Module):
    """
    Electron-passing neural-network module

    :param n_types: Total number of types in the system
    :param embed_dim: Dimension the types are reduced to in the embedding layer
    :param update_model: flax module that generates the updated node states from the generated messages
    :param message_generators: tuple of flax modules that generate the messages for generating node state updates.
        The length of the tuple defines the number of message passes performed
    :param electron_pass_generators: tuple of flax modules that generate the electron passes.
        The length of the tuple defines the number of electron passes performed
    :param mixer: Callable that combines descriptors, node states and embedding. Default: Concatenation
    :param aggregate_nodes_fn: Function to aggregate the electron passes for each receiver node.
        Default applies the cutoff mask before performing jax.ops.segment_sum
    """

    n_types: int
    embed_dim: int
    update_model: flax.linen.Module
    message_generators: tuple[flax.linen.Module, ...]
    electron_pass_generators: tuple[flax.linen.Module, ...]
    mixer: Callable[
        [jnp.ndarray, jnp.ndarray, jnp.ndarray], jnp.ndarray
    ] = lambda descriptors, node_states, embedding: jnp.concatenate(
        [descriptors, node_states, embedding],
        axis=1,
    )
    aggregate_nodes_fn: Callable[
        [jnp.ndarray, jnp.ndarray, jnp.ndarray, int], jnp.ndarray
    ] = _aggregate_nodes_fn

    def setup(self) -> None:
        self.embed = flax.linen.Embed(self.n_types, self.embed_dim)

    def __call__(self, graph: jraph.GraphsTuple) -> jraph.GraphsTuple:
        # Read data that does not change in iterations from graph
        nodes, edges, receivers, senders, _, _, _ = graph
        n_edges = receivers.shape[0]
        graph_edges = edges[:, :-1]  # shape=(n_edges, edge_dim)
        cutoff_masks = edges[:, -1:]  # shape(n_edges, )
        embedded_types = self.embed(
            nodes["types"]
        )  # shape=(n_batch * atom_count + 1, embed_dim)

        # Message passing phase
        for message_generator in self.message_generators:
            nodes = graph.nodes
            node_info = self.mixer(
                nodes["descriptors"], nodes["node_states"], embedded_types
            )  # shape=(n_batch * atom_count + 1, descriptor_dim + node_state_dim + embed_dim)
            sender_info = node_info[
                senders
            ]  # shape=(n_edges, descriptor_dim + node_state_dim + embed_dim)
            receiver_info = node_info[
                receivers
            ]  # shape=(n_edges, descriptor_dim + node_state_dim + embed_dim)
            edges_vw = jnp.concatenate(
                [receiver_info, sender_info, graph_edges], axis=-1
            )
            messages = message_generator(edges_vw)  # shape=(n_edges, )
            aggregated_messages = jax.tree_util.tree_map(
                lambda message: jax.ops.segment_sum(
                    message, receivers, nodes["descriptors"].shape[0]
                ),
                messages,
            )
            update_input = jnp.concatenate(
                [nodes["node_states"], aggregated_messages], axis=-1
            )
            updates = self.update_model(
                update_input
            )  # shape=(n_batch * atom_count + 1, node_state_dim)
            graph = graph._replace(
                nodes={
                    "features": nodes["features"],
                    "descriptors": nodes["descriptors"],
                    "node_states": updates,
                    "types": nodes["types"],
                }
            )

        # Electron passing phase
        for pass_generator in self.electron_pass_generators:
            nodes = graph.nodes
            node_info = self.mixer(
                nodes["descriptors"], nodes["node_states"], embedded_types
            )
            sender_info = node_info[
                senders
            ]  # shape=(n_edges, descriptor_dim + node_state_dim + embed_dim)
            receiver_info = node_info[
                receivers
            ]  # shape=(n_edges, descriptor_dim + node_state_dim + embed_dim)
            sender_features = nodes["features"][senders].reshape(
                (n_edges, -1)
            )  # shape=(n_edges, feature_dim)
            receiver_features = nodes["features"][receivers].reshape(
                (n_edges, -1)
            )  # shape=(n_edges, feature_dim)
            edges_vw = jnp.concatenate(
                [
                    receiver_features,
                    sender_features,
                    receiver_info,
                    sender_info,
                    graph_edges,
                ],
                axis=-1,
            )
            edges_wv = jnp.concatenate(
                [
                    sender_features,
                    receiver_features,
                    sender_info,
                    receiver_info,
                    graph_edges,
                ],
                axis=-1,
            )
            electron_passes = jnp.subtract(
                pass_generator(edges_vw), pass_generator(edges_wv)
            )
            aggregated_passes = jax.tree_util.tree_map(
                lambda e_passes: self.aggregate_nodes_fn(
                    e_passes,
                    receivers,
                    cutoff_masks,
                    nodes["descriptors"].shape[0],
                ),
                electron_passes,
            )
            graph = graph._replace(
                nodes={
                    "features": (
                        nodes["features"]
                        - aggregated_passes.reshape(nodes["features"].shape)
                    )
                    * (nodes["types"] >= 0)[:, jnp.newaxis],
                    "descriptors": nodes["descriptors"],
                    "node_states": nodes["node_states"],
                    "types": nodes["types"],
                }
            )

        return graph


@dataclass
class EPNNModelInfo:
    timestamp: datetime
    embed_dim: int
    node_state_dim: int
    e_passes: int
    n_passes: int
    r_cut: float
    r_switch: float
    update_model_widths: list[int]
    message_generator_widths: list[int]
    pass_generator_widths: list[int]
    random_seed: int
    params: dict[str, Any]
    misc_info: Any
