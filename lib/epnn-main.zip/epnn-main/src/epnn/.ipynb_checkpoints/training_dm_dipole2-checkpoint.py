#!/usr/bin/env python
"""Functionalities for EPNN model training"""

from typing import Any, Callable, Sequence

import flax
import jax
import jax.numpy as jnp
import jraph
import optax
from learned_optimization.optimizers.opt_to_optax import (
    GradientTransformationWithExtraArgs,
)
from neuralil.training import ValidationStatistic
from tqdm.auto import tqdm

from .utils import split_array_equal_size


def create_training_step(
    model: flax.linen.Module,
    optimizer: optax.GradientTransformation,
    calc_loss: Callable,
) -> Callable:
    """
    Create a function that performs a single training step

    :param model: To be trained flax model
    :param optimizer: optax optimizer that applies the gradients to train the model
    :param calc_loss: Function that calculates the loss.
        Arguments: (predictions, ground_truths, types)
    :return: Function that applies the model, calculates the loss and updates model and optimizer.
        Arguments: (optimizer_state, model_parameters, batch_graph, batch_ground_truth).
        Returns: (loss_value, optimizer_state, model_parameters)
    """

    @jax.jit
    def training_step(
        optimizer_state: jnp.ndarray,
        model_params: flax.core.FrozenDict,
        batch_graph: jraph.GraphsTuple,
        batch_ground_truth: jnp.ndarray,
        batch_ground_position:jnp.ndarray,
    ):
        """
        Run a single training step

        :param optimizer_state: Current optax optimizer state
        :param model_params: Current flax model state
        :param batch_graph: Graph of implicitly batched data (graphs padded with one extra node to max edge count)
        :param batch_ground_truth: Ground truth charges for the current batch
        :return: Loss value, updated optax optimizer state, updated flax model state
        """

        def invoke_loss(params: flax.core.FrozenDict) -> jnp.ndarray:
            """
            Compute the loss by applying the model and loss function passed

            :param params: Current flax model state
            :return: Loss value
            """
            result_graph,pre_dipole = model.apply(params, batch_graph)
            #pred_values = result_graph.nodes["features"][:-1].ravel()
            pred_values = result_graph.nodes["features"][:-1]
            atom_types = result_graph.nodes["types"][:-1]
            atom_types1 = jnp.sqrt(atom_types + 1)

            print('train batch_ground_position',batch_ground_position.shape)

            pred_charges=pred_values.reshape(
                            batch_ground_position.shape[0],
                            batch_ground_position.shape[1])
            pre_dipole = pre_dipole.reshape(
                            batch_ground_position.shape[0],
                            3)

            pred_charges = jnp.asarray(pred_charges) # calculated chagres
            pred_charges = jnp.expand_dims(pred_charges,axis=-1)
            print('train_pred_charges.shape',pred_charges.shape)
            print('train_pred_dipole.shape',pre_dipole.shape)

            dipole_monment_pred=[]
            for i in range(batch_ground_truth.shape[0]):
                one_dipole_moment_pred_1=(pred_charges[i]*batch_ground_position[i]).sum(axis=0)
                #one_dipole_moment_pred= (pred_charges[i]).sum(axis=0)
                one_dipole_moment_pred_2 = pre_dipole[i]
                one_dipole_moment_pred = one_dipole_moment_pred_1*0.7 + one_dipole_moment_pred_2*0.3
                dipole_monment_pred.append(one_dipole_moment_pred)

            dipole_moment_pred_arr=jnp.array(dipole_monment_pred)

            return calc_loss(dipole_moment_pred_arr, batch_ground_truth, atom_types)

        calc_loss_and_grad = jax.value_and_grad(invoke_loss)
        loss_value, loss_grad = calc_loss_and_grad(model_params)
        if isinstance(optimizer, GradientTransformationWithExtraArgs):
            kwargs = dict(extra_args=dict(loss=loss_value))
        else:
            kwargs = dict()
        updates, optimizer_state = optimizer.update(
            loss_grad, optimizer_state, model_params, **kwargs
        )
        model_params = optax.apply_updates(model_params, updates)
        return loss_value, optimizer_state, model_params

    return training_step


def create_training_epoch(
    train_graphs: Sequence[jraph.GraphsTuple],
    train_ground_truths: jnp.ndarray,
    train_ground_positions: jnp.ndarray,
    training_step_driver: Callable,
    progress_bar: bool = True,
) -> Callable:
    """
    Create a function that performs a training epoch

    :param train_graphs: Iterable containing implicitly batched jraph graph representations
    :param train_ground_truths: Array containing ground truth values
        jax.numpy.ndarray(shape=(n_configurations_train, feature_dim))
    :param training_step_driver: Driver function for a training step on a single batch
        Arguments: (optimizer_state, model_parameters, batch_graph, batch_ground_truth)
        Returns: (loss_value, optimizer_state, model_parameters)
    :param progress_bar: Boolean specifying if progress bar should be displayed or not
    :return: Function performing a single training epoch. Returns the updated optimizer state and model parameters
        Arguments: (optimizer_state, model_parameters)
        Returns: (optimizer_state, model_parameters)
    """

    n_batches = train_ground_truths.shape[0] // len(train_graphs)
    print('train n_batches',n_batches)
    ground_truths_batched = split_array_equal_size(
        train_ground_truths,
        n_batches 
       # * jnp.product(jnp.array(train_ground_truths.shape[1:])),
    )

    ground_positions_batched = split_array_equal_size(
        train_ground_positions,
        n_batches
        #* jnp.product(jnp.array(train_ground_positions.shape[1:])),
    )

    ground_positions_batched = jnp.asarray(split_array_equal_size(train_ground_positions, n_batches))  

    def training_epoch(
        optimizer_state: jnp.ndarray, model_params: flax.core.FrozenDict
    ):
        """
        Run a single, full training epoch

        :param optimizer_state: Current state of the optax.GradientTransformation optimizer
        :param model_params: Current state of the flax model
        :return: Tuple (optimizer_state, model_parameters) with the updated states
        """
        iterator = tqdm(
            iterable=zip(train_graphs, ground_truths_batched,ground_positions_batched),
            total=len(train_graphs),
            dynamic_ncols=True,
            disable=not progress_bar,
        )
        iterator.set_description(f"EPOCH #{training_epoch.epoch + 1}")
        for batch_graph, batch_ground_truth,batch_ground_position in iterator:
            loss_value, optimizer_state, model_params = training_step_driver(
                optimizer_state, model_params, batch_graph, batch_ground_truth,batch_ground_position,
            )
            if progress_bar:
                iterator.set_postfix(loss=loss_value)
        training_epoch.epoch += 1
        return optimizer_state, model_params

    training_epoch.epoch = 0
    return training_epoch


# See neuralil.training.ValidationStatistic for documentation
# Note: Since the graphs are implicitly batched there is no need to create a vectorized version of these statistics.
# The map functions takes the batched values, they are then just reduced and post-processed
rmse_validation_statistic = ValidationStatistic(
    lambda pred, obs, types: ((pred - obs) ** 2 / (types >= 0).sum()).sum(),
    jnp.sum,
    lambda batch_values, n_batches: jnp.sqrt(batch_values / float(n_batches)),
)


mae_validation_statistic = ValidationStatistic(
    lambda pred, obs, types: (jnp.fabs(pred - obs) / (types >= 0).sum()).sum(),
    jnp.sum,
    lambda batch_values, n_batches: batch_values / float(n_batches),
)


def _create_batch_validation_calculator(
    model: flax.linen.Module,
    validation_statistics: dict[Any, ValidationStatistic],
):
    """
    Create a jit-compiled calculator that applies the map function of all validation statistics
    and returns a dictionary containing the values for the batch

    :param model: flax model to be validated
    :return: jit-compiled calculator for a single batch that takes the model parameters,
    jraph graph representation for the batch data and the corresponding ground truths as arguments.
        Arguments: (batch_graph, batch_ground_truths)
        Returns: dict[Any, jnp.ndarray] containing validation statistics for the batch
    """

    @jax.jit
    def batch_calculator(
        model_params: flax.core.FrozenDict,
        batch_graph: jraph.GraphsTuple,
        batch_ground_truths: jnp.ndarray,
        batch_ground_position: jnp.ndarray,
    ) -> dict[Any, jnp.ndarray]:
        """
        Evaluate the model on a single batch

        :param model_params: Current state of the flax model
        :param batch_graph: jraph graph representation of the input data for the batch
            (graphs padded with one extra node to max edge count)
        :param batch_ground_truths: Ground truth data for the batch
        :return: Dictionary containing validation statistics
        """
        result_graph,pre_dipole = model.apply(model_params, batch_graph)
        #pred_values = result_graph.nodes["features"][:-1].ravel()
        pred_values = result_graph.nodes["features"][:-1]
        atom_types = result_graph.nodes["types"][:-1]
        
        print('Val batch_ground_position',batch_ground_position.shape)
        charges=pred_values.reshape(
                            batch_ground_position.shape[0],
                            batch_ground_position.shape[1])
        pre_dipole = pre_dipole.reshape(
                            batch_ground_position.shape[0],
                            3)
                            
        charges = jnp.asarray(charges) # calculated chagres
        charges = jnp.expand_dims(charges,axis=-1)
        dipole_moment_pred=[]
        

        for d in range(len(batch_ground_truths)):
               one_dipole_moment_pred_1 =(charges[d]*batch_ground_position[d]).sum(axis=0)
               #one_dipole_moment_pred=(charges[d]).sum(axis=0)
               one_dipole_moment_pred_2=pre_dipole[d]
               one_dipole_moment_pred = one_dipole_moment_pred_1*0.7 + one_dipole_moment_pred_2*0.3
               dipole_moment_pred.append(one_dipole_moment_pred)
        dipole_moment_pred_arr=jnp.array(dipole_moment_pred)

        return {
            stat_key: validation_statistics[stat_key].map_function(
                dipole_moment_pred_arr, batch_ground_truths, atom_types,
            )
            for stat_key in validation_statistics
        }

    return batch_calculator


def create_validation_step(
    model: flax.linen.Module,
    validation_statistics: dict[Any, ValidationStatistic],
    val_graphs: Sequence[jraph.GraphsTuple],
    val_ground_truths: jnp.ndarray,
    val_ground_positions: jnp.ndarray,
    progress_bar: bool = True,
) -> Callable[[flax.core.FrozenDict], dict[Any, jnp.ndarray]]:
    """
    Create a function that performs a single validation step using all validation data

    :param model: flax model to be evaluated
    :param validation_statistics: Dictionary of ValidationStatistic named tuples to be applied to each batch.
        (See neuralil.training.ValidationStatistic for documentation)
    :param val_graphs: Iterable of batched jraph graph representations
    :param val_ground_truths: Array containing ground truth values
        jax.numpy.ndarray(shape=(n_configurations_val, feature_dim))
    :param progress_bar: Boolean specifying if progress bar should be displayed or not
    :return: Function performing a single validation step. Returns a dictionary of validation statistics
        Arguments: model_parameters
        Returns: validation_stats
    """

    batch_calculator = _create_batch_validation_calculator(
        model, validation_statistics
    )
    n_batches = val_ground_truths.shape[0] // len(val_graphs)
    print('Val n_batches',n_batches)
    ground_truths_batched = split_array_equal_size(
        val_ground_truths,
        n_batches 
        #* jnp.product(jnp.array(val_ground_truths.shape[1:])),
    )
    
    ground_positions_batched = split_array_equal_size(
        val_ground_positions,
        n_batches 
       # * jnp.product(jnp.array(val_ground_positions.shape[1:])),
    )
    
    ground_positions_batched = jnp.asarray(split_array_equal_size(val_ground_positions, 
        n_batches))

    def validation_step(
        model_params: flax.core.FrozenDict,
    ) -> dict[Any, jnp.ndarray]:
        """
        Run a full validation step

        :param model_params: State of the flax model
        :return: Dictionary containing validation statistics
        """
        iterator = tqdm(
            iterable=zip(val_graphs, ground_truths_batched, ground_positions_batched),
            total=len(val_graphs),
            dynamic_ncols=True,
            disable=not progress_bar,
        )
        iterator.set_description("VALIDATION")

        reduced_statistics = {
            stat_key: 0.0 for stat_key in validation_statistics
        }
        for batch_graph, batch_ground_truths, batch_ground_position in iterator:
            batch_statistics = batch_calculator(
                model_params, batch_graph, batch_ground_truths, batch_ground_position,
            )
            reduced_statistics = {
                stat_key: validation_statistics[stat_key].reduce_function(
                    jnp.array(
                        [
                            batch_statistics[stat_key],
                            reduced_statistics[stat_key],
                        ]
                    )
                )
                for stat_key in validation_statistics
            }

        return {
            stat_key: validation_statistics[stat_key].postprocess_function(
                reduced_statistics[stat_key], len(val_graphs)
            )
            for stat_key in validation_statistics
        }

    return validation_step
