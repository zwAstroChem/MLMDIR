#!/usr/bin/env python
"""Preprocessing routines for building of EPNN models"""

from functools import partial
from typing import Callable

import jax
import jax.numpy as jnp
import jraph
import numpy as np
from neuralil.bessel_descriptors import center_at_atoms

from .utils import split_array_equal_size


def _aux_function_f(t: jnp.ndarray) -> jnp.ndarray:
    """First auxiliary function used in the definition of the smooth bump"""
    return jnp.where(t > 0.0, jnp.exp(-1.0 / jnp.where(t > 0.0, t, 1.0)), 0.0)


def _aux_function_g(t: jnp.ndarray) -> jnp.ndarray:
    """Second auxiliary function used in the definition of the smooth bump"""
    f_of_t = _aux_function_f(t)
    return f_of_t / (f_of_t + _aux_function_f(1.0 - t))


def smooth_cutoff(
    r: jnp.ndarray, r_switch: float, r_cut: float
) -> jnp.ndarray:
    """
    One-dimensional smooth cutoff function based on a smooth bump

    :param r: The radii at which the function must be evaluated.
    :param r_switch: The radius at which the function starts differing from 1.0
    :param r_cut: The radius at which the function becomes exactly 0.0
    """
    r_switch2 = r_switch * r_switch
    r_cut2 = r_cut * r_cut

    return 1.0 - _aux_function_g((r * r - r_switch2) / (r_cut2 - r_switch2))


def get_cutoff_masks(
    distances: jnp.ndarray, r_switch: float, r_cut: float
) -> jnp.ndarray:
    """
    For a set of distances get the corresponding cutoff mask with the smooth cutoff being defined
    by r_switch and r_cut

    :param distances: Array of distances. jax.numpy.ndarray(shape=(n_configurations, atom_count, atom_count))
    :param r_switch: Radius at which the function starts differing from 1.0
    :param r_cut: Cutoff radius at which the function becomes equal to 0.0
    :return: Cutoff mask array. jax.numpy.ndarray(shape=(n_configurations, atom_count, atom_count))
    """
    partial_smooth_cutoff = partial(
        smooth_cutoff, r_switch=r_switch, r_cut=r_cut
    )
    return jax.jit(jax.vmap(partial_smooth_cutoff))(distances)


def get_init_charges(types: jnp.ndarray, charge_dict: dict) -> jnp.ndarray:
    """
    Get the initial charges for each atom in a set of configurations based on its atom type

    :param types: Array of encoded atom type numbers. jax.numpy.ndarray(shape=(n_configurations, atom_count))
    :param charge_dict: Dictionary mapping the atom type numbers (keys) to their charges (values)
    :return: Array containing individual charges for each atom. jax.numpy.ndarray(shape=(batch_size, atom_count))
    """
    return jnp.array(np.vectorize(charge_dict.get)(types))


def create_batched_graph(
    descriptors: jnp.ndarray,
    distances: jnp.ndarray,
    types: jnp.ndarray,
    init_node_features: jnp.ndarray,
    cutoff_mask: jnp.ndarray,
    r_cut: float,
    node_state_dim: int,
) -> jraph.GraphsTuple:
    """
    Creates a jraph graph representation based on atom descriptors, distances between atoms, types and initial charges
    for batches of atoms. The node states are initialized to zeros for the given dimension

    :param descriptors: Array of atom descriptors. jax.numpy.ndarray(shape=(batch_size, atom_count, descriptor_dim))
    :param distances: Array of interatomic distances. jax.numpy.ndarray(shape=(batch_size, atom_count, atom_count))
    :param types: Array of encoded types. jax.numpy.ndarray(shape=(batch_size, atom_count))
    :param init_node_features: Array of initial node features. jax.numpy.ndarray(shape=(batch_size, feature_dim))
    :param cutoff_mask: Cutoff mask for node and edge interactions.
        jax.numpy.ndarray(shape=(batch_size, atom_count, atom_count))
    :param r_cut: Cutoff radius
    :param node_state_dim: Dimension of the node states determined during message passing
    :return: jraph.GraphsTuple representing the graphs defined by the arguments
    """
    batch_size = descriptors.shape[0]
    atom_count = descriptors.shape[1]
    # Work with descriptors "implicitly batched" by flattening batch_size and atom_count axes
    descriptors = descriptors.reshape((batch_size * atom_count, -1))
    # Calculate number of all nodes and edges
    batched_distances_flat = distances.reshape((batch_size, -1))
    n_edges = jnp.count_nonzero(
        jnp.logical_and(
            batched_distances_flat > 0, batched_distances_flat < r_cut
        ),
        axis=1,
    )
    n_nodes = jnp.repeat(jnp.array([atom_count]), batch_size)
    # Get indices of flattened distance arrays where positive and within cutoff
    flattened_distances = distances.ravel()
    flattened_indices = jnp.nonzero(
        jnp.logical_and(flattened_distances > 0, flattened_distances < r_cut)
    )[0]

    # Make sure that there are only edges between nodes of the same graph
    # Index offsets to be added onto the outer products used to compute senders and receivers
    batch_ranges = jnp.reshape(
        jnp.repeat(
            jnp.arange(batch_size) * atom_count, atom_count * atom_count
        ),
        (batch_size, atom_count, atom_count),
    )
    # Vectorized computation of senders and receivers: Build (repeated) array for all combinations,
    # offset the individual batches and select possible communications based on atom distances
    # Bi-directional graph: Node is a sender and a receiver at the same time
    all_graph_nodes = jnp.reshape(
        jnp.tile(
            jnp.outer(jnp.ones(atom_count), jnp.arange(atom_count)).astype(
                jnp.int32
            ),
            batch_size,
        ),
        (batch_size, atom_count, atom_count),
    )
    all_graph_nodes_transposed = jnp.transpose(all_graph_nodes, axes=(0, 2, 1))
    senders = jnp.add(all_graph_nodes_transposed, batch_ranges).ravel()[
        flattened_indices
    ]
    receivers = jnp.add(all_graph_nodes, batch_ranges).ravel()[
        flattened_indices
    ]

    # Select cutoff mask from arrays based on same criteria as sender and receiver nodes
    cutoff_mask = cutoff_mask.ravel()[flattened_indices]
    # No edge encoding used in current implementation, raw distances
    edges_distances = flattened_distances[flattened_indices]

    # Node features contain the charges, the descriptors are included in the edge features
    return jraph.GraphsTuple(
        nodes={
            "features": init_node_features.reshape(
                (batch_size * atom_count, -1)
            ),
            "descriptors": descriptors,
            "types": types.ravel(),
            "node_states": jnp.zeros(
                (batch_size * atom_count, node_state_dim)
            ),
        },
        senders=senders,
        receivers=receivers,
        edges=jnp.concatenate(
            [edges_distances[:, jnp.newaxis], cutoff_mask[:, jnp.newaxis]],
            axis=-1,
        ),
        n_node=n_nodes,
        n_edge=n_edges,
        globals=None,
    )


def create_batched_graph_list(
    all_positions: jnp.ndarray,
    all_cells: jnp.ndarray,
    all_descriptors: jnp.ndarray,
    all_types: jnp.ndarray,
    all_init_node_features: jnp.ndarray,
    r_cut: float,
    r_switch: float,
    node_state_dim: int,
    n_batch: int,
    array_splitter: Callable[
        [jnp.ndarray, int, int],
        list[jnp.ndarray],
    ] = split_array_equal_size,
) -> list[jraph.GraphsTuple]:
    """
    Build a list of batched graphs from given information about the configurations.
    Using the default array splitter: If the number of configurations cannot be evenly split
    into batches with the requested size the remainder will be discarded

    :param all_positions: Array of atom positions for all configurations.
        jax.numpy.ndarray(shape=(n_configurations, atom_count, 3))
    :param all_cells: Array of cells for all systems. jax.numpy.ndarray(shape=n_configurations, 3, 3))
    :param all_descriptors: Array of descriptors for all atoms and configurations.
        jax.numpy.ndarray(shape=(n_configurations, atom_count, descriptor_dim))
    :param all_types: Array of types for all atoms and configurations.
        jax.numpy.ndarray(shape=(n_configurations, atom_count))
    :param all_init_node_features: Initial node feature values for all atoms in all configurations.
        jax.numpy.ndarray(shape=(n_configurations, atom_count, feature_dim))
    :param r_switch: Radius at which the function starts differing from 1.0 (for computation cutoff mask)
    :param r_cut: Cutoff radius at which the function becomes equal to 0.0
    :param node_state_dim: Dimension of the node states determined during message passing
    :param n_batch: Number of configurations in one batch, determines number and size of created graphs
    :param array_splitter: Callable that splits the arrays in batches.
        Args:
            in_array: Array to be split.
            size: Size of the individual batches.
            axis: Axis to split the array along.
        Returns:
            list of jax.numpy.ndarray objects (split arrays).
        Default discards the remainder if the size of the last array would not match.
    :return: List of jraph.GraphTuple representations of the batched systems
    """
    n_samples = all_positions.shape[0]
    if n_samples < n_batch:
        raise ValueError(
            f"Arrays too short ({n_samples}) for the requested batch size ({n_batch})."
        )

    # Interatomic distances for all systems, shape=(n_configurations, atom_count, atom_count)
    all_distances = jax.vmap(center_at_atoms)(
        all_positions, all_types, all_cells
    )[1]
    # Cutoff masks for all systems, shape=(n_configurations, atom_count, atom_count)
    all_cutoff_masks = get_cutoff_masks(all_distances, r_switch, r_cut)
    # Split all arrays into batches, discard remainder
    splitter = partial(array_splitter, size=n_batch, axis=0)
    batched_distances = splitter(all_distances)
    batched_cutoff_masks = splitter(all_cutoff_masks)
    batched_descriptors = splitter(all_descriptors)
    batched_types = splitter(all_types)
    batched_init_features = splitter(all_init_node_features)
    # Build list of implicitly batched graphs
    graphs = [
        create_batched_graph(
            descriptors,
            distances,
            types,
            init_features,
            cutoff_mask,
            r_cut,
            node_state_dim,
        )
        for descriptors, distances, types, init_features, cutoff_mask in zip(
            batched_descriptors,
            batched_distances,
            batched_types,
            batched_init_features,
            batched_cutoff_masks,
        )
    ]
    # Pad to maximum edge count, return padded graphs (un-pad with jraph.unpad_with_graphs)
    padded_node_count = jnp.sum(graphs[0].n_node) + 1
    padded_graph_count = n_batch + 1
    max_edge_count = max(jnp.sum(graph.n_edge) for graph in graphs)
    return [
        jraph.pad_with_graphs(
            graph,
            n_node=padded_node_count,
            n_edge=max_edge_count,
            n_graph=padded_graph_count,
        )
        for graph in graphs
    ]
