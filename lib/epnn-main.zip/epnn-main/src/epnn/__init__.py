from pathlib import Path

__all__ = ["model", "preprocessing", "training", "utils"]
PKG_ROOT_DIR = str(Path(__file__).parent.absolute())
