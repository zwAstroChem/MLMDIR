#!/usr/bin/env python
"""Various EPNN-related utility functions"""

import jax.numpy as jnp
import jraph


def split_array_train_val(
    in_array: jnp.ndarray, n_train: int, n_validate: int
) -> tuple[jnp.ndarray, jnp.ndarray]:
    """
    Split an array in training and validation sections

    :param in_array: Array to be split
    :param n_train: Number of training inputs
    :param n_validate: Number of validation inputs
    :return: Tuple of training and validation arrays obtained by splitting input array
    """
    return jnp.split(in_array, (n_train, n_train + n_validate))[:2]


def split_array_equal_size(
    in_array: jnp.ndarray, size: int, axis: int = 0
) -> list[jnp.ndarray]:
    """
    Split an array into evenly sized arrays.
    If the array size does not allow for a fully even split the remainder will be discarded

    :param in_array: Array to be split
    :param size: Size of the individual arrays obtained by splitting in_array
    :param axis: Axis along which to split in_array. Default 0
    :return: List of arrays obtained by splitting in_array
    """
    split_axis_shape = in_array.shape[axis]
    split_array = jnp.split(
        in_array, jnp.arange(size, split_axis_shape, size), axis=axis
    )
    if split_axis_shape % size != 0:
        split_array = split_array[:-1]
    return split_array


def get_nodes_from_graph(
    graph: jraph.GraphsTuple,
) -> tuple[jnp.ndarray, jnp.ndarray, jnp.ndarray, jnp.ndarray]:
    """
    Get the node features and descriptors from a batched and padded graph

    :param graph: Implicitly batched and padded jraph graph representation
    :return: Tuple of arrays:
        First array contains the node features, shape=((n_configurations, atom_count, flattened_feature_dim)).
        Second array contains the descriptors, shape=((n_configurations, atom_count, flattened_descriptor_dim)).
        Third array contains the node states, shape=((n_configurations, atom_count, node_state_dim)).
        Last array contains the types, shape=((n_configurations, atom_count))
    """
    unpadded_graph = jraph.unpad_with_graphs(graph)
    features = unpadded_graph.nodes["features"]
    descriptors = unpadded_graph.nodes["descriptors"]
    node_states = unpadded_graph.nodes["node_states"]
    types = unpadded_graph.nodes["types"]
    n_batch = unpadded_graph.n_node.shape[0]
    n_atoms = descriptors.shape[0] // n_batch
    return (
        features.reshape((n_batch, n_atoms, -1)),
        descriptors.reshape((n_batch, n_atoms, -1)),
        node_states.reshape((n_batch, n_atoms, -1)),
        types.reshape((n_batch, n_atoms)),
    )
