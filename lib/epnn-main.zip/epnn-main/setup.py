from setuptools import find_packages, setup

setup(
    name="epnn",
    version="0.1",
    description="An Electron-Passing Neural Network implementation based on JAX",
    author="EPNN contributors",
    author_email="johannes.schoerghuber@tuwien.ac.at",
    package_dir={"": str("src")},
    python_requires=">=3.9, <3.11",
    packages=find_packages(where="./src"),
    install_requires=[
        "flax",
        "jax",
        "jaxlib",
        "jraph",
        "neuralil",
        "numpy",
        "optax",
        "tqdm",
    ],
)
