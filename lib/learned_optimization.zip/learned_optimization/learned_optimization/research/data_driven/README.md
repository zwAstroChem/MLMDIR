# General-Purpose In-Context Learning by Meta-Learning Transformers

Research code for the paper https://arxiv.org/abs/2212.04458