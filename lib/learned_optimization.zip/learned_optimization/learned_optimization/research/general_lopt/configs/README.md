Configs used in meta-training.

At the moment, these are not wired up to run outside of Google's infra.