Learned Optimizers
====================

.. automodule:: learned_optimization.learned_optimizers.base


API
---

.. autofunction:: learned_optimization.learned_optimizers.base.LearnedOptimizer
.. autofunction:: learned_optimization.learned_optimizers.base.LearnableSGD
.. autofunction:: learned_optimization.learned_optimizers.base.LearnableSGDM
.. autofunction:: learned_optimization.learned_optimizers.base.LearnableAdam