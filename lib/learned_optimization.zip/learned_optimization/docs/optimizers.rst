Optimizers
===========

.. automodule:: learned_optimization.optimizers.base


API
---

.. autofunction:: learned_optimization.optimizers.base.Optimizer
.. autofunction:: learned_optimization.optimizers.base.SGD
.. autofunction:: learned_optimization.optimizers.base.SGDM
.. autofunction:: learned_optimization.optimizers.base.Adam
