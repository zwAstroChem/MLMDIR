# NeuralIL

This repository contains more recent releases of the neural-network force field described in the paper

A Differentiable Neural-Network Force Field for Ionic Liquids

Hadrián Montes-Campos, Jesús Carrete, Sebastian Bichelmaier, Luis M. Varela & Georg K. H. Madsen

Journal of Chemical Information and Modeling 62 (2022) 1, 88–101

DOI: [10.1021/acs.jcim.1c01380](https://doi.org/10.1021/acs.jcim.1c01380)

The original version can be found in the supporting information of the article. These releases contain numerous improvements in terms of features and implementation. Releases used for specific publications will be tagged here.

## Quick start

Example scripts for training a normal network and several kinds of ensembles are provided in the `examples/` subdirectory.

Another script, `md_example`, shows how to use the ASE calculator interface for inference, in particular to run a simple molecular dynamics simulation.
